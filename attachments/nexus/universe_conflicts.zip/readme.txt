FAQ 1.3

BugFix:
The 1.3 patch includes all the fixes from the 1.2 patch. 
-In addition it fixes a problem in Mission 16 causing the game to crash (Nexus having troubles with the assignment of certain NPCs)
-Mission 15 has been made slightly easier (removed a plasma gun from Starlight station and replaced a Destroyers offensive weaponry with lasers only.
Starlight stations shield has also been made weaker).

FAQ 1.2

BugFix:
The 1.2 patch fixes the problem that Captain Jageda wasn't assigned to the Arkanoid correctly. It also restores the bonus mission to its original state.
Just unzip the file in the universe folder and overwrite all files.

FAQ 1.1


BugFix:
The 1.1 version now contains the missing model for the gas station used in Mission 12. I'm really sorry that this thing slipped in the initial release.
The procedure is the same, just extract the entire .zip file in your nexus folder and follow the instructions below.


FAQ 1.0


-So, what is this "New Conflicts" all about ?
It's a complete campaign with a total of 15 missions, all tied into the Nexus Universe (so if you played Nexus you will recognize the ships 
and factions involved). The campaign is set in a slightly alternative version of the Nexus universe,perhaps a little darker and not as happy 
ending as the "real" one. The campaign will off course have the whole background story integrated into the game (thanks to the diary system).

-Is this just a set of mod missions ?
No.The campaign uses the original Nexus engine, so you won't have to bother with the "mod" system anymore,
this will include the solar system overwiev, diaries, the configuration screen, medals, promotions, a growing fleet of ships.....

-I'm missing artificial gods, deux ex machinas, silly dialogs, bossy admirals,etc....
If you really have this feeling then I did something right :-)! I tried to get rid of all the stuff that made my head ache 
when thinking about the stories behind many games/movies. The story behind "New Conflicts" should be pretty solid but if you 
find any holes in my plot, write me !

-How do I install it ?
First of all, you need "daTool" from "elFarto". You can find a link in the download section. With it, you have to extract the nexus_00.dat 
file in your Nexus installation folder. This dat file contains all the missions, briefings, ship stats, etc. from the original campaing. 
Since we need to replace this data with the new one, you will have to extract its content. If you're new to Nexus and unsure how to do this 
just take a look here in the official forum, it's explained in great detail there. If you're lazy I'll just quote "elFarto"
--------------------------------------------
Remember daTool is a command line tool.
To extract a DAT file to the current directory, use:
datool x "C:\Program Files\Nexus - The Jupiter Incident\nexus_00.dat"
Obviously replacing where you installed Nexus if it is different.
The other DAT files, e.g. nexus_01.dat, nexus_02.dat, are the movies, and can't be extracted.
---------------------------------------------

-Ok, I did that, what now ?
After you extrected the nexus_00.dat file (and got rid, or even better, renamed the original nexus_00.dat file) you will see a lot of folders
and files in your Nexus directory. If you're seeing a "universe" folder and the game is still running (give it a try, there should be no difference
to the state before the extraction) you did everything right. Now just copy the content of the .zip file right into the Nexus directory.
The .zip file contains a new "universe" folder (named "universe_conflicts", and as you guessed by now, this is where the new mission and all 
the other stuff is located) and two .bat files named "conflicts_start.bat" and "conflicts_end.bat".
Simply double-click on the "conflicts_start.bat" ! Et voila, you have just installed the "New Conflicts" mod. Just start a new campaign in Nexus 
and you're good to go. If you ever get tired of my mod just double-click on the "conflicts_end.bat" and you're back to the original game. If you name
your campaigns accordingly (say conflicts-campaign and original-campaign) you can even switch easily between my mod and the original game by keeping 
savegames and not getting confused which savegame belongs to which campaign.

-Are there any known bugs ?
Unfortunately there are. Although I dare say that they are rather a problem of the Nexus engine than my mod.
A very annoying "bug" is that sometimes lines of dialog are left out. I found no solution for this problem since it only happens sometimes.
If you encounter this bug it will most probably be in Mission 12 or 13. So if you're wondering why a dialog is kinda short or you're missing 
a reply....it's there, believe me. This happened to me in about 30% of my tests, and funnily the missing/skipped parts vary ! A simple restart 
didn't always fix the problem...so I'm counting on your feedback where and if you're missing dialog.
Other than that there are no known bugs....which doesn't mean there are none. Give me your feedback, patches will be delivered as fast as 
possible (and I bet I can beat Mithis on that....well, then again that's no big trick :-)

-I love you, the mod is fantastic, you're my hero,etc....
If you feel this way express your feelings right away, either on the officila Nexus forum or write me a mail 
(or use the feedback link on the homepage). Of course, all other opinions are also welcome.