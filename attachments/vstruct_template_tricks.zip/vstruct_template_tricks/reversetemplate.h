#pragma once
#ifndef REVERSE_TEMPLATE_H
#define REVERSE_TEMPLATE_H
/****************************************************************************
*<
*	DESCRIPTION: Simple template hackz to create a new type from an existing
*	             type by reversing its template parameters. Useful if you do
*	             recursive templates (like VertexStructure) but the order of
*	             parameters are completely opposite what you want.
*
*	EXAMPLE:
*	    using my_tuple = std::tuple<int, bool, char>;
*	    
*	    static_assert(
*	    	std::is_same<
*	    		typename reverse_simpl<my_typle>::type,
*	    		std::tuple<char, bool, int>>::value,
*	    	"");
*
*	CREATED BY: Richard Thier (MagosIT) for Asysnth SAS
*	BASED ON: https://blog.mattbierner.com/stupid-template-tricks-reversing-template-parameters-on-templated-types/
*
*	Rem.: I have implemented the simple case only as that was all we need.
*
*>	Copyright (c) 2020, All Rights Reserved. (Asynth)
 ****************************************************************************/

// Empty case (used for creating empty param list types) //
// ----------------------------------------------------- //

// forward declaration
template<typename>
struct templated_empty_case;

// declaration
template <template<typename...> class T, typename... TArgs>
struct templated_empty_case<T<TArgs...>>
{
	using type = T<>;
};

// Reversing //
// --------- //

// forward declaration: reverse template arguments
template<
	typename T, // Input that still needs to be reversed
	typename = typename templated_empty_case<T>::type> // Already reversed output part
struct reverse_simpl;

// recursion base case template specialization: if "input" has empty arg list, the output is the full arg list when reversed.
template<
    template <typename...> class T,
    typename... TArgs>
struct reverse_simpl<
    typename templated_empty_case<T<TArgs...>>::type, // Input: empty
    T<TArgs...>> // output: all (if any)
{
    using type = T<TArgs...>; // output is the whole
};

// recursion main:
// The main reversal implementation gets the head of the input type list
// and conses it onto the output type list. The remainder of the input
// type list is recursively reversed (x:xs style if this would be haskell)
template<
    template<typename...> class T,
    typename x,
    typename... xs,
    typename... done>
struct reverse_simpl<
    T<x, xs...>,
    T<done...>>
{
    using type = typename reverse_simpl<T<xs...>, T<x, done...>>::type;
};

#endif // !REVERSE_TEMPLATE_H
