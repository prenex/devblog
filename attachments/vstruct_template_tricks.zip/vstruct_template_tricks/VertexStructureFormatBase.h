#pragma once
#ifndef __VERTEX_STRUCTURE_FORMAT_BASE
#define __VERTEX_STRUCTURE_FORMAT_BASE

#include <vector>
#include "VSForm.h"

/**
 * Base-class of all VertexStructureFormats.
 *
 * Useful when you want to keep a reference or
 * a unique_ptr to a generated VertexStructureFormat
 * and refer to it where type information is not available
 * anymore but the format parts should be known at runtime.
 */
struct VertexStructureFormatBase {
	// BEWARE: This only works because the VSForm's memory
	//         layout is always completely the same!!!
	// Array (vector) is empty in the base-case.

	/** The parts of this vertex format */
	std::vector<VSForm> forms;
};

#endif // ! __VERTEX_STRUCTURE_FORMAT_BASE

