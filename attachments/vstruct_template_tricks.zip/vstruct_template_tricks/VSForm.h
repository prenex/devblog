#pragma once
#ifndef __VS_FORM_H
#define __VS_FORM_H
/***************************************************************
*<
*	DESCRIPTION: VertexStructureFormat parts and their cases
*                used in VertexStructure template recursion too
*
*	CREATED BY: Richard Thier (MagosIT) for Asysnth SAS
*
*>	Copyright (c) 2020, All Rights Reserved. (Asynth)
 ***************************************************************/

// Base class and macros //
// --------------------- //

/**
 * Common base-class for VertexStructure format parts.
 *
 * BEWARE: Do not subclass this directly while not using the VS_FORM macro!
 *
 * All of the subclasses take the same bytes and in same layout so they
 * can be put into an array of VSForm without losing data! Usually you
 * would need references or pointers to avoid a crash, but here you don't!
 *
 * So you can do this:
 *
 *		VSForm arr[4];
 *
 *		Pos_3f p; Nor_3f n; Uv_2f uv1; Uv_2f uv2;
 *
 *		arr[0] = p;
 *		arr[1] = n;
 *		arr[2] = uv1;
 *		arr[3] = uv2;
 *
 * Then you can safely do this too:
 *
 *      Pos_3f tmp = arr[0]
 *		arr[0] = arr[3];
 *		arr[3] = tmp;
 *
 *		if(arr[0].size == arr[2].size) {
 *			printf("OK\n");
 *		} else {
 *			printf("Cannot happen\n");
 *		}
 *
 * Rem.: The "size" property do not refer to our own VSForm object size,
 *       but size of what the object represents (like 3*4 bytes for Pos_3f as that is 3 floats)
 */
struct VSForm {
public:
	/**
	 * How many bytes the format-part takes that this format specifier represents?
	 *
	 * Not the same as sizeof(this)!
	 */
	const size_t size;
protected:
	VSForm(size_t s) : size(s) {};
};

/**
 * Creates a subtype of VSForm
 *
 * Example: VS_FORM(Pos_3f, 3, float)
 */
#define VS_FORM(name, count, type)              \
struct name : public VSForm {                   \
	name() : VSForm((count) * sizeof(type)) {}; \
};                                              \
static_assert(sizeof(name) == sizeof(VSForm));  \

// Supported VSForms //
// ----------------- //

/** x, y, z */
VS_FORM(Pos_3f, 3, float)

/** i, j, k */
VS_FORM(Nor_3f, 3, float)

/** u, v */
VS_FORM(Uv_2f, 2, float)

// TODO: Add further ones here similarly. If you add an element here, also update VertexStructure and VertexStructureFormat accordingly pls.
//       See: "// TODO: Add your new VSForm cases here" in those files to see where and how to add.
// TODO: Maybe we can avoid keeping track of changes at three places if I would create some "smart tricky X-MACRO" stuff for it...

#endif // !__VS_FORM_H
