#ifndef __VERTEX_STRUCTURE_H
#define __VERTEX_STRUCTURE_H
/**********************************************************************
*<
*	DESCRIPTION: Vertex-structure optimized for continous in-memory
*	             representation while still being handy to use.
*
*	This approach is inspired by the one used in the objmaster library
*	and general recursive template construction best practices.
*
*	CREATED BY: Richard Thier (MagosIT) for Asysnth SAS
*
*>	Copyright (c) 2020, All Rights Reserved. (Asynth)
 **********************************************************************/

#include <cstdint>
#include "reversetemplate.h"
#include "VSForm.h"

// Data holder helper classes //
// -------------------------- //

/** u, v - also data here because of layouting in VertexStructureImpl */
struct Uv_2f_holder {
	float u;
	float v;
};

// Recursive template implementation //
// --------------------------------- //

// Rem.: Beware that alignas always uses the highest number. Alignment is needed to save/load directly in binary.

// Forward decl for underlying implementation template - use VertexStructure instead!
template<typename ...ARGS> struct alignas(4) VertexStructureImpl;

// Recursion - template specializations will describe what each recursive step does!
template<typename H, typename ...T> struct alignas(4) VertexStructureImpl<H, T...> : public VertexStructureImpl<T...> { };

/**
 * Baseclass / recursion base of VertexStructure that added fields classes all inherit from.
 * Specialize like VertexStructure<Uv_2f, Nor_3f, Pos_3f> to layout as position, normal, textcoord.
 */
template<> struct alignas(4) VertexStructureImpl<> {
public:
	/** Returns raw memory data pointer to this vertex structure. Lenght can be got using "sizeof" operator in compile time. */
	inline uint8_t *bytes() const {
		// We have no vpointer, no anything so this should work and the pointer points to the first field.
		return (uint8_t*) this;
	}
};

// Specializations //
// --------------- //

/** x, y, z */
template<typename ...T> struct alignas(4) VertexStructureImpl<Pos_3f, T...> : public VertexStructureImpl<T...> {
public:
	float x;
	float y;
	float z;
};

/** i, j, k */
template<typename ...T> struct alignas(4) VertexStructureImpl<Nor_3f, T...> : public VertexStructureImpl<T...> {
public:
	float i;
	float j;
	float k;
};

/** u, v */
template<typename ...T> struct alignas(4) VertexStructureImpl<Uv_2f, T...> : public VertexStructureImpl<T...> {
public:
	Uv_2f_holder uvs[1];
};

/** u2, v2 - only supported if uv data descriptor is after an other uv descriptor */
template<typename ...T> struct alignas(4) VertexStructureImpl<Uv_2f, Uv_2f, T...> : public VertexStructureImpl<T...> {
public:
	Uv_2f_holder uvs[2];
};

/** u3, v3 - only supported if uv data descriptor is already after another two uv descriptor */
template<typename ...T> struct alignas(4) VertexStructureImpl<Uv_2f, Uv_2f, Uv_2f, T...> : public VertexStructureImpl<T...> {
public:
	Uv_2f_holder uvs[3];
};

/** u4, v4 - only supported if uv data descriptor is already after another three uv descriptor */
template<typename ...T> struct alignas(4) VertexStructureImpl<Uv_2f, Uv_2f, Uv_2f, Uv_2f, T...> : public VertexStructureImpl<T...> {
public:
	Uv_2f_holder uvs[4];
};

/** u5, v5 - only supported if uv data descriptor is already after another 4 uv descriptor */
template<typename ...T> struct alignas(4) VertexStructureImpl<Uv_2f, Uv_2f, Uv_2f, Uv_2f, Uv_2f, T...> : public VertexStructureImpl<T...> {
public:
	Uv_2f_holder uvs[5];
};

/** u6, v6 - only supported if uv data descriptor is already after another 5 uv descriptor */
template<typename ...T> struct alignas(4) VertexStructureImpl<Uv_2f, Uv_2f, Uv_2f, Uv_2f, Uv_2f, Uv_2f, T...> : public VertexStructureImpl<T...> {
public:
	Uv_2f_holder uvs[6];
};

/** u7, v7 - only supported if uv data descriptor is already after another 6 uv descriptor */
template<typename ...T> struct alignas(4) VertexStructureImpl<Uv_2f, Uv_2f, Uv_2f, Uv_2f, Uv_2f, Uv_2f, Uv_2f, T...> : public VertexStructureImpl<T...> {
public:
	Uv_2f_holder uvs[7];
};

/** u8, v8 - only supported if uv data descriptor is already after another 7 uv descriptor */
template<typename ...T> struct alignas(4) VertexStructureImpl<Uv_2f, Uv_2f, Uv_2f, Uv_2f, Uv_2f, Uv_2f, Uv_2f, Uv_2f, T...> : public VertexStructureImpl<T...> {
public:
	Uv_2f_holder uvs[8];
};

// TODO: Add new VSForm cases here

// TODO: You can add more UV channels similarly here. Likely the above can be automated by
//       using MACRO expansion if you really want, but I just used vsvim to generate these.

// MAIN CLASS (to use) //
// ------------------- //

// Rem.: VertexStructureImpl has memory layout completely the opposite
//       of what one would expect so we inherit from it with reversed
//       template parameter order to get better usability here!

/**
 * Vertexdata structure struct template. Can define vertexdata in any layout
 * - with easy usage while also being continous in memory!
 *
 * Examples:
 *     VertexStructure<Pos_3f, Nor_3f, Uv_2f> vs;
 *        vs.x = 1.0f;
 *        vs.y = 2.0f;
 *        vs.z = 3.0f;
 *        vs.i = 11.0f;
 *        vs.j = 12.0f;
 *        vs.k = 13.0f;
 *        vs.uvs[0].u = 42.0f;
 *        vs.uvs[0].v = 0.42f;
 *
 *     VertexStructure<Pos_3f, Nor3F, Uv_2f, Uv_2f> vsx;
 *        vs.x = 1.0f; vs.y = 2.0f; vs.z = 3.0f;
 *        vs.i = 11.0f; vs.j = 12.0f; vs.k = 13.0f;
 *        vs.uvs[0].u = 42.0f;
 *        vs.uvs[0].v = 0.42f;
 *        vs.uvs[1].u = 13.0f;
 *        vs.uvs[1].v = 10.0f;
 *
 * The UV channels must be right after each other for this to work. Layout in memory is as expected:
 *
 *   vs: 1, 2, 3, 11, 12, 13, 42, 0.42
 *   vsx: 1, 2, 3, 11, 12, 13, 42, 0.42, 13, 10
 *
 * BEWARE: Do not over-index UV channels!
 *         The current implementation supports: 8 channels at most - when defined!
 */
template<typename ...ARGS> struct alignas(4) VertexStructure : public reverse_simpl<VertexStructureImpl<ARGS...>>::type {
	/**
	 * This practically "stores" (compile time) the ARGS parameter pack for later extraction by other templates...
	 *
	 * See: VertexStructureFormat.h for a usage example.
	 *
	 * For understanding:
	 *
	 * VertexStructure<Pos_3f, Nor_3f, Uv_2f>::ApplyParamPack<std::tuple>::type test;
	 *
	 * becomes an: std::tuple<Pos_3f, Nor_3f, Uv_2f>
	 */
	template < template<typename ...> class T > struct ApplyParamPack {
		typedef T<ARGS...> type;
	};
};

#endif // __VERTEX_STRUCTURE_H
