#pragma once
#ifndef __VERTEX_STRUCTURE_FORMAT_H
#define __VERTEX_STRUCTURE_FORMAT_H

#include <vector>
#include "VSForm.h"
#include "VertexStructure.h"
#include "VertexStructureFormatBase.h"

// Recursive template //
// ------------------ //

/** Forward declaration */
template<typename ...ARGS> struct VertexStructureFormatImpl { };

/** Recursion - template specializations will describe what each recursive step does! */
template<typename X, typename ...XS> struct VertexStructureFormatImpl<X, XS...> : VertexStructureFormatImpl<XS...> { };

/**
 * Base-class of all vertex structure formats
 * - also base of template recursion.
 *
 * Rem.: Use std::unique_ptr<VertexStructureFormatBase> to store this.
 */
template<> struct VertexStructureFormatImpl<> : public VertexStructureFormatBase { };

// Specializations //
// --------------- //

/**
 * Macro to create template specializations more easily
 *
 * Example: VS_FORMAT_IMPL(Pos_3f)
 */
#define VS_FORMAT_IMPL(vsform)                                                                                  \
template<typename ...XS> struct VertexStructureFormatImpl<vsform, XS...> : VertexStructureFormatImpl<XS...> {   \
	VertexStructureFormatImpl() {                                                                               \
		forms.push_back(std::move(vsform()));                                                                   \
	}                                                                                                           \
};                                                                                                              \

// Specializations
VS_FORMAT_IMPL(Pos_3f)
VS_FORMAT_IMPL(Nor_3f)
VS_FORMAT_IMPL(Uv_2f)
// TODO: Add new VSForm cases here if needed.

// Main template //
// ------------- //

// Forward declaration
/**
 * Generate a VertexStructureFormat type from the given VertexStructure type parameter.
 *
 * The resulting type has a "forms" vector that contains the list/array of the format parts - usable for runtime and saves.
 *
 * Rem.: Use std::unique_ptr<VertexStructureFormatBase> to store these.
 */
template<typename VS> struct VertexStructureFormat;

// We are using constructors and inheritance to fill in a vector, but once again it would be in reverse order!
// Rem.: Specialization is needed for this to work!!! That is the only way to do proper pattern matching here.
/**
 * Generate a VertexStructureFormat type from the given VertexStructure type parameter.
 *
 * The resulting type has a "forms" vector that contains the list/array of the format parts - usable for runtime and saves.
 *
 * Rem.: Use std::unique_ptr<VertexStructureFormatBase> to store these.
 */
template<typename ...T> struct VertexStructureFormat<VertexStructure<T...>> : public reverse_simpl<VertexStructureFormatImpl<T...>>::type { };

// Format shortcuts //
// ---------------- //

// PNU
using Pos_3f_Nor_3f_Uv_2f = typename VertexStructureFormat<VertexStructure<Pos_3f, Nor_3f, Uv_2f>>;
using Pos_3f_Nor_3f_Uv_2f_Uv_2f = typename VertexStructureFormat<VertexStructure<Pos_3f, Nor_3f, Uv_2f, Uv_2f>>;
using Pos_3f_Nor_3f_Uv_2f_Uv_2f_Uv_2f = typename VertexStructureFormat<VertexStructure<Pos_3f, Nor_3f, Uv_2f, Uv_2f, Uv_2f>>;
using Pos_3f_Nor_3f_Uv_2f_Uv_2f_Uv_2f_Uv_2f = typename VertexStructureFormat<VertexStructure<Pos_3f, Nor_3f, Uv_2f, Uv_2f, Uv_2f, Uv_2f>>;
using Pos_3f_Nor_3f_Uv_2f_Uv_2f_Uv_2f_Uv_2f_Uv_2f = typename VertexStructureFormat<VertexStructure<Pos_3f, Nor_3f, Uv_2f, Uv_2f, Uv_2f, Uv_2f, Uv_2f>>;
using Pos_3f_Nor_3f_Uv_2f_Uv_2f_Uv_2f_Uv_2f_Uv_2f_Uv_2f = typename VertexStructureFormat<VertexStructure<Pos_3f, Nor_3f, Uv_2f, Uv_2f, Uv_2f, Uv_2f, Uv_2f, Uv_2f>>;
using Pos_3f_Nor_3f_Uv_2f_Uv_2f_Uv_2f_Uv_2f_Uv_2f_Uv_2f_Uv_2f = typename VertexStructureFormat<VertexStructure<Pos_3f, Nor_3f, Uv_2f, Uv_2f, Uv_2f, Uv_2f, Uv_2f, Uv_2f, Uv_2f>>;
using Pos_3f_Nor_3f_Uv_2f_Uv_2f_Uv_2f_Uv_2f_Uv_2f_Uv_2f_Uv_2f_Uv_2f = typename VertexStructureFormat<VertexStructure<Pos_3f, Nor_3f, Uv_2f, Uv_2f, Uv_2f, Uv_2f, Uv_2f, Uv_2f, Uv_2f, Uv_2f>>;

// NPU
using Nor_3f_Pos_3f_Uv_2f = typename VertexStructureFormat<VertexStructure<Nor_3f, Pos_3f, Uv_2f>>;
using Nor_3f_Pos_3f_Uv_2f_Uv_2f = typename VertexStructureFormat<VertexStructure<Nor_3f, Pos_3f, Uv_2f, Uv_2f>>;
using Nor_3f_Pos_3f_Uv_2f_Uv_2f_Uv_2f = typename VertexStructureFormat<VertexStructure<Nor_3f, Pos_3f, Uv_2f, Uv_2f, Uv_2f>>;
using Nor_3f_Pos_3f_Uv_2f_Uv_2f_Uv_2f_Uv_2f = typename VertexStructureFormat<VertexStructure<Nor_3f, Pos_3f, Uv_2f, Uv_2f, Uv_2f, Uv_2f>>;
using Nor_3f_Pos_3f_Uv_2f_Uv_2f_Uv_2f_Uv_2f_Uv_2f = typename VertexStructureFormat<VertexStructure<Nor_3f, Pos_3f, Uv_2f, Uv_2f, Uv_2f, Uv_2f, Uv_2f>>;
using Nor_3f_Pos_3f_Uv_2f_Uv_2f_Uv_2f_Uv_2f_Uv_2f_Uv_2f = typename VertexStructureFormat<VertexStructure<Nor_3f, Pos_3f, Uv_2f, Uv_2f, Uv_2f, Uv_2f, Uv_2f, Uv_2f>>;
using Nor_3f_Pos_3f_Uv_2f_Uv_2f_Uv_2f_Uv_2f_Uv_2f_Uv_2f_Uv_2f = typename VertexStructureFormat<VertexStructure<Nor_3f, Pos_3f, Uv_2f, Uv_2f, Uv_2f, Uv_2f, Uv_2f, Uv_2f, Uv_2f>>;
using Nor_3f_Pos_3f_Uv_2f_Uv_2f_Uv_2f_Uv_2f_Uv_2f_Uv_2f_Uv_2f_Uv_2f = typename VertexStructureFormat<VertexStructure<Nor_3f, Pos_3f, Uv_2f, Uv_2f, Uv_2f, Uv_2f, Uv_2f, Uv_2f, Uv_2f, Uv_2f>>;

// TODO: Add the more rare ones if they will be handy.

#endif // !__VERTEX_STRUCTURE_FORMAT_H

